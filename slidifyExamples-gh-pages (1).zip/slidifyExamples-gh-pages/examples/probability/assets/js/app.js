$(document).ready(function(){
  // $("pre:has(code)").addClass('build');
  // $("p:has(img)").addClass('build')
  // var pop = Popcorn.vimeo("player", "http://player.vimeo.com/video/41823197");
  // var mytimings = [{"slide":1,"time":1361386121505},{"time":15660,"slide":2,"action":"gotoSlide"},{"time":67211,"slide":3,"action":"gotoSlide"},{"time":71362,"slide":3,"action":"nextSlide"},{"time":81665,"slide":3,"action":"nextSlide"},{"time":92802,"slide":3,"action":"nextSlide"},{"time":100178,"slide":3,"action":"nextSlide"}] ;
  // syncSlides(mytimings, pop);
});


// <script src='https://grockit.com/answers/scripts/grockitize.js' id='link_grockitizer'>
// </script>
// <script>g('c655d8cb2');</script>
