---
title: Quiz 1
subtitle: Data Analysis
--- &radio

## Question 10

Suppose we take a sample of people in Baltimore and observe that younger people have taken more Coursera courses. We use an inferential data analysis to show a relationship between age and Coursera courses. Which of the following statements are true based only on our analysis?

1. The reason that younger people take more Coursera courses is that they understand technology better.
2. If we took a census of all people in Boston, we would expect to see that the younger a person was, the more likely they were to have taken a Coursera course.
3. If we took a census of all people in Baltimore, we would expect to see that the younger a person was, the more likely they were to have taken a Coursera course.
4. When comparing two people in Baltimore, the one who is younger will always have taken more Coursera courses.
