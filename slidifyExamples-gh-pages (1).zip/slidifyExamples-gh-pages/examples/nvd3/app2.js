;(function(){
  var params = {"x":"day","y":"freq","group":"sex","geom":"multiBarChart","id":"chart4","file":"app2.js"}, 
     data = [{"day":"Fri","sex":"Female","freq":9},{"day":"Fri","sex":"Male","freq":10},{"day":"Sat","sex":"Female","freq":28},{"day":"Sat","sex":"Male","freq":59},{"day":"Sun","sex":"Female","freq":18},{"day":"Sun","sex":"Male","freq":58},{"day":"Thur","sex":"Female","freq":32},{"day":"Thur","sex":"Male","freq":30}];
     drawChart(params, data)
  })()