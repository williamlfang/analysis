---
title: Slidify
subtitle: Reproducible HTML5 Slides
author: Ramnath Vaidyanathan
job: Assistant Professor, McGill 
framework: slideous
url:
  lib: ../../libraries
---

## Test Slide


```r
require(ggplot2)
qplot(wt, mpg, data = mtcars)
```

![plot of chunk unnamed-chunk-1](assets/fig/unnamed-chunk-1.png) 


