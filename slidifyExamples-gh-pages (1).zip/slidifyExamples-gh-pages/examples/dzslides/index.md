---
title: DZSlides with Slidify
author: Ramnath Vaidyanathan
framework: dzslides
url: {lib: ../../libraries}
mode: none
---

# My Presentation
<footer>by Ramnath Vaidyanathan</footer>

---

Some random text: But I've never been to the moon! You can see how I lived before I met you. Also Zoidberg. I could if you hadn't turned on the light and shut off my stereo.

---

### Incremental List

> - Point 1
> - Point 2
> - Point 3

---

>Who's brave enough to fly into something we all keep calling a death sphere?

---

## Part 2

---


<div>
  <figure> 
    <img src="http://placekitten.com/g/800/600">
    <figcaption>Figure Caption</figcaption>
  </figure>
</div>

---

### ggplot

![plot of chunk unnamed-chunk-2](assets/fig/unnamed-chunk-2.png) 



